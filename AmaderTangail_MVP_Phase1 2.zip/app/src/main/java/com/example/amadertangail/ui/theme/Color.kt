package com.example.amadertangail.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val TangailGreen = Color(0xFF2E7D32)
val TangailRed = Color(0xFFC62828)
val TangailGold = Color(0xFFFBC02D)
